﻿using System;
using System.Collections.Generic;

#nullable disable

namespace Todo.Models
{
    public partial class UploadFilePostDto
    {
        public string Name { get; set; }
        public string Src { get; set; }
    }
}
